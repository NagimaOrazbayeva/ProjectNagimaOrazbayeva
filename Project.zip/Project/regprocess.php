<?php
session_start();
include 'connection.php';

if (isset($_POST['registration'])) {
	$name = $_POST['name'];
	$surname = $_POST['surname'];
	$login = $_POST['login'];
	$password = $_POST['password'];
	
	$gender = $_POST['gender'];
	$city = $_POST['city'];


	$query = "INSERT INTO registration VALUES (null,'$name','$surname','$login','$password','$gender','$city')";
	if (mysqli_query($conn, $query)) {
		$_SESSION['login'] = $login;
    	header('location: project.php');
	} else {
    	echo "Owibka " . $query . "<br>" . mysqli_error($conn);
	}
}else{
	header('location: registration.php');
}
?>
?>