<?php
$localhost='localhost';
$dbuser='root';
$dbpassword='';
$dbname='projectastana';
$conn = mysqli_connect($localhost,$dbuser,$dbpassword,$dbname);
 ?>