<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/jquery.min.js"></script>

	<title>Information</title>

<style type="text/css">
  body{
    background-color: #cb85ee;
  }
</style>
</head>
<body><div style="height:1300px;width:1200px;"><div style="float:left;"><embed src="Background_Music.mp3" height="30" width="30" autostart="true"></embed></div>
<nav style="background-color: black;width:1365px;" class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="project.php"><span style="color: #68228b;" class="glyphicon glyphicon-home" aria-hidden="true"></span></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="galery.php"><span style="color: #68228b;" class="glyphicon glyphicon-camera" aria-hidden="true"></span> Galery<span class="sr-only">(current)</span></a></li>
        <li><a href="presentation.php"><span style="color: #68228b;" class="glyphicon glyphicon-facetime-video" aria-hidden="true"></span> Presentation</a></li>
        <li><a href="information.php"><span style="color:#68228b;" class="glyphicon glyphicon-file" aria-hidden="true"></span> Information about Astana</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span style="color:#68228b;" class="glyphicon glyphicon-align-left" aria-hidden="true"></span> Categories<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="foods.php">Food</a></li>
            <li><a href="attractions.php">Attractions</a></li>
            
          </ul>
        </li>
      </ul>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" style="color:#68228b;background-color:#cb85ee;font-size: 16px;" class="form-control" placeholder="Search">
        </div>
        <button type="submit" style="color: white;background-color: #68228b;" class="btn btn-default">Find</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.php"><span style="color: #68228b;" class="glyphicon glyphicon-user" aria-hidden="true"></span> Log in</a></li>
        <li class="dropdown">
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
 <div><h3 style="text-align:center;font-size:23px;">General information</h3></div>
 <div style="border-color: red;border: 5px;margin-left: 6%;"><p style="text-align:center;font-size:18px;">ASTANA: Capital of the Republic of Kazakhstan</p></div>
 <div  style="margin-left: 40%;width:307px;"><pre style="background-color:#cb85ee ;border-color:  #68228b;font-size:15px;">Before 1961 – City of Akmolinsk
1961 - 1992 – City of Tselinograd
1993 - 1998 – City of Akmola</pre></div>
<div style="margin-left: 10%;width:1100px;"><pre style="background-color:#cb85ee;border-color:  #68228b;font-size:15px;">20.10.1997 After the edict by the President of RK the city of Akmola is declared Capital of the Republic of Kazakhstan
06.05.1998 Akmola is renamed by the decree of the President of RK into the city of Astana
Metropolitan Area of Astana, New Borders: 710.2 sq. km.
Population: 600 200 inhabitants. Astana is inhabited by the representatives of more than 100 nationalities.
Climate: sharply continental: moderately hot summer and long-lasting frosty winter.
Geographic position: 510 10’ of North latitude and 710 30’ of East longitude.
Local time: Astana is in Time Zone 5. Local time in relation to the zero meridian is GMT +06.00</pre></div>
<div style="margin-left: 2%;width:1300px;"><pre style="background-color:#cb85ee;border-color:  #68228b;font-size:15px;">In year 2007 12371 newborns were registered in the capital, that is 2345 newborns more than in year 2006. For the period, the number of the deceased has made 3642 people, that is 82 people less than in the previous year.
In the total population of the city of Astana people younger than labour force age (0-15 ) make 116.3 thousand people, the number of active working age people (16-63 ) makes 438.2 thousand, the number of people older than labour force age (63 and older) makes 48.2 thousand people.
In year 2007, economically active population has made 314.7 thousand people.
Gross Regional Product: It gives unprejudiced reflection of general dynamical development of the city of Astana a parameter of gross regional product (GRP) which, after the results of year 2007, has made 1393.1 billion tenge, growth rate by last year has made 45.6 % (the share of Astana in the republic is 10.9 %). GRP per capita for the period in question has made 2367.2 billion tenge and has increased for 39.1 %, this is the second parameter in the republic after the Atyrau Region (1260.7 billion tenge).
Trade occupies a significant place in formation Astana’s GRP. Its share in GRP structure makes 25 %, other branches make 40 %, construction - 18 %, transport and communication - 12 %, industry - 4 %, agriculture - around 1 %.
Investments: For year 2007 fixed capital investments have made 4363.9 billion tenge, quantum index – 116.7 % by year 2006. In the republic’s fixed capital investment volume the share of Astana’s volume has made 13.5 % (12.3 % by year 2006).
The greatest share in total fixed capital investment flow is directed to the government - 38 %, construction - 34 %, real estate, rent and consumer services - 13 %, the share of other branches makes 15 %.
As of January-March, 2008, fixed capital investments have made 88.8 billion tenge (140.4 % by January-March, 2007). In the republican fixed capital investment volume the share of the city of Astana has made 143 % (11.8 % in January-March, 2007).
International trade turnover: If to track international trade turnover development in 2007, it has made USD 8.7 billion and has increased, as compared with 2006, to 54.5 %, with the CIS countries included – USD 1.9 billion (as compared with the previous year it has increased 1.5 times), with the countries outside the CIS. – USD 6.8 billion (has increased 1.6 times). For January-March, 2008 international trade turnover has reached USD 2.5 billion, growth rate by the similar period of the last year has made 27.2 %.
Export deliveries: In 2007 they have made USD 4.45 billion and have grown almost 1.3 times by 2006, for January-March, 2008 export has made USD 1.9 billion, growth rate by the similar period in 2007 has made 164.2 %.
The capital’s export has strongly pronounced geographical orientation: the share of the countries outside the CIS. in the total amount of export for 2007 has made 95.1 %. Basic consumers are Switzerland (57.5 %), France (20.0 %), China (6.7 %), the UK (29 %), the Netherlands (1.8 %), Turkey (1.7%), Russia (0.5 %), Belarus (0.5 %).
In year 2007, as compared with 2006, per basic commodity groups that have significant share in export, export volumes increased: supplies of mineral fuel and its derivatives (petrochemicals, gas, etc.) have increased 1.4 times, 1.8 times – those of machines, equipment, vehicles, instruments and devices. Metallurgical industry product supplies have increased 1.7 times. Alongside with it, food and agricultural raw material supplies have increased 2.9 times.
Import deliveries: In 2007 they made USD 3.6 billion and increased 1.7 times as compared with year 2006, for January-March, 2008 import made USD 0.5 billion, as compared with the similar period in 2007, it has decreased to 30 %.
In year 2007 as compared with 2006, non-C.I.S. countries accounted for 55.4% of all import deliveries, the CIS. countries – 44.6 %. The highest volumes of import into the country’s capital were brought from Russia (34.3 %), the USA (10.3 %), China (9.4 %), Germany (7.5 %), France (5.5 %), Ukraine (5.1 %), Turkey (4.7 %), the Republic of Korea (2.9 %), Italy (2.3 %), the Netherlands (2.0 %), Switzerland (1.8 %), Japan (1.2 %), Belarus (0.9 %).
What remains prevailing in import supplies is the import of equipment, vehicles, the share of machines in 2007 made 59% and has grown almost double, as compared with the last year. International trade balance as per the results of year 2007 has been positive, at the rate of USD 1.4 billion.
At present the capital of the country carries out trading with 121 countries around the world, including capitals with which twin-town relationships are maintained: Moscow, Minsk, Kishinev, Kiev, Kazan, Seoul, Riga, Warsaw, Budapest, Baku, Cairo, Bangkok, Berlin, Vilnius, Ankara, Ushak, Tashkent, Beijing, etc.</pre></div>
<br>
<br>
<button onclick="loadDoc()">Get information about Admin</button>
<p id="info"></p>
<script>
function loadDoc() {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (xhttp.readyState == 4 && xhttp.status == 200) {
      document.getElementById("info").innerHTML = xhttp.getAllResponseHeaders();
    }
  };
  xhttp.open("GET", "admin_info.txt", true);
  xhttp.send();
}
</script>
</body>
</html>