<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/jquery.min.js"></script>

	<title>PresentationAstana</title>
	<style type="text/css">
  body{
    background-color: #caff70;
  }
</style>
</head>
<body>
  <div style="height:2000px;width:1200px;"><div style="float:left;"><embed src="Background_Music.mp3" height="30" width="30" autostart="true"></embed></div>
<nav style="background-color: black;width:1365px;" class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="project.php"><span style="color: #006400;" class="glyphicon glyphicon-home" aria-hidden="true"></span></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="galery.php"><span style="color:#006400;" class="glyphicon glyphicon-camera" aria-hidden="true"></span> Galery<span class="sr-only">(current)</span></a></li>
        <li><a href="presentation.php"><span style="color: #006400;" class="glyphicon glyphicon-facetime-video" aria-hidden="true"></span> Presentation</a></li>
        <li><a href="information.php"><span style="color: #006400;" class="glyphicon glyphicon-file" aria-hidden="true"></span> Information about Astana</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span style="color: #006400;" class="glyphicon glyphicon-align-left" aria-hidden="true"></span> Categories<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="foods.php">Food</a></li>
            <li><a href="attractions.php">Attractions</a></li>
         
          </ul>
        </li>
      </ul>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" style="color: #006400;background-color: #caff70;font-size: 16px;" class="form-control" placeholder="Search">
        </div>
        <button type="submit" style="color: white;background-color:#006400;" class="btn btn-default">Find</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.php"><span style="color: #006400;" class="glyphicon glyphicon-user" aria-hidden="true"></span> Log in</a></li>
        <li class="dropdown">
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<div><video autoplay loop muted class="bgvideo" id="bgvideo" style="margin-left: 30px;">
   <source style="width:1600px;" src="astana.mp4" type="video/mp4"></source>
  </video></div>
 <div><video autoplay loop muted class="bgvideo" id="bgvideo" style="margin-left: 30px;">
   <source style="width:1600px;" src="astan2.mp4" type="video/mp4"></source>
  </video></div>
</body>
</html>