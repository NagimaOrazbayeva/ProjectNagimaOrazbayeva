<!DOCTYPE html>
<html>
<head><meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/jquery.min.js"></script>

	<title>Shopping</title>

<style type="text/css">
  body{
    background-color:#ffe4c4;
  }
</style>
</head>
<body><div style="height:2000px;width:1200px;"><div style="float:left;"><embed src="Background_Music.mp3" height="30" width="30" autostart="false"></embed></div>
<nav style="background-color: black;width:1365px;" class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="project.php"><span style="color: #8b7d6b;" class="glyphicon glyphicon-home" aria-hidden="true"></span></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="galery.php"><span style="color: #8b7d6b;" class="glyphicon glyphicon-camera" aria-hidden="true"></span> Galery<span class="sr-only">(current)</span></a></li>
        <li><a href="presentation.php"><span style="color: #8b7d6b;" class="glyphicon glyphicon-facetime-video" aria-hidden="true"></span> Presentation</a></li>
        <li><a href="information.php"><span style="color: #8b7d6b;" class="glyphicon glyphicon-file" aria-hidden="true"></span> Information about Astana</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span style="color: #8b7d6b;" class="glyphicon glyphicon-align-left" aria-hidden="true"></span> Categories<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="foods.php">Food</a></li>
            <li><a href="attractions.php">Attractions</a></li>
            
          </ul>
        </li>
      </ul>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" style="color: #8b7d6b;background-color: #ffe4c4;font-size: 16px;" class="form-control" placeholder="Search">
        </div>
        <button type="submit" style="color: white;background-color: #8b7d6b;" class="btn btn-default">Find</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.php"><span style="color: #8b7d6b;" class="glyphicon glyphicon-user" aria-hidden="true"></span> Log in</a></li>
        <li class="dropdown">
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<div><h2 style="font-size:30px;text-align:center;font-family:Comic">KHAN SHATYR</h2></div>
<div><img style="height:1000px;width:1000px;margin-left:150px;"src="han-shatyr1.jpg" ></div>
<div style="margin-left: 80px;border:5px;border-color:black;margin-top:30px;"><p style="text-align: center;">Khan Shatyr Shopping and Entertainment Center is a new symbol of the capital of Kazakhstan, the first and the Only Lifestyle center in Astana that features world class shopping and entertainment under the same roof. Designed by famous British Architect, Lord Norman Foster, Khan Shatyr is the biggest tent in the world and also is the biggest shopping center in Kazakhstan. The main idea of Khan Shatyr is to create an atmosphere of comfort and antidote to the stress of daily life with the variety of greenery and fresh flowers. “Khan Shatyr” is located on the New Astana Center Axis which is also called “the Millennium Axis” with magnificent views of the Presidential Palace. On weekends the number of visitors reaches 30,000 people per day. Many world brands as Zara, New Yorker,Massimo Dutti, GAP, Bershka etc. represented in Astana for the first time. The sand of the beach has been flown out from the Maldives and under floor heating gives the natural beach feeling when walking on the sand.Khan Shatyr organizes different events on weekends, conducts lotteries and arranges various activities for guests in the central area called the atrium.

</p></div>
<div style="border-style:solid;border-width:1px;float:left;background-color:#d4d4cb;width:600px;padding-left:20px;padding-top:25px;padding-bottom:10px;margin-left:300px">
<form action="mailto:myemail@domain.com" method="post">
<p>Comments and suggestions:<br><textarea name="comments" rows="5" cols="80"></textarea><br><br>
<input type="submit" value="Send"></p>
</form>
</div>
<br>
<br>
<br>
<br>
<br>
<br><br>
<br>
<br><br>
<br>
<br>
<div><h2 style="font-size:30px;text-align:center;font-family:Comic">KERUEN</h2></div>
<div><img style="height:800px;width:1000px;margin-left:150px;"src="keruen.jpg" ></div>
<div style="margin-left: 80px;border:5px;border-color:black;margin-top:30px;"><p style="text-align: center;">Khan Shatyr Shopping and Entertainment Center is a new symbol of the capital of Kazakhstan, the first and the Only Lifestyle center in Astana that features world class shopping and entertainment under the same roof. Designed by famous British Architect, Lord Norman Foster, Khan Shatyr is the biggest tent in the world and also is the biggest shopping center in Kazakhstan. The main idea of Khan Shatyr is to create an atmosphere of comfort and antidote to the stress of daily life with the variety of greenery and fresh flowers. “Khan Shatyr” is located on the New Astana Center Axis which is also called “the Millennium Axis” with magnificent views of the Presidential Palace. On weekends the number of visitors reaches 30,000 people per day. Many world brands as Zara, New Yorker,Massimo Dutti, GAP, Bershka etc. represented in Astana for the first time. The sand of the beach has been flown out from the Maldives and under floor heating gives the natural beach feeling when walking on the sand.Khan Shatyr organizes different events on weekends, conducts lotteries and arranges various activities for guests in the central area called the atrium.

</p></div>
<div style="border-style:solid;border-width:1px;float:left;background-color:#d4d4cb;width:600px;padding-left:20px;padding-top:25px;padding-bottom:10px;margin-left:300px">
<form action="mailto:myemail@domain.com" method="post">
<p>Comments and suggestions:<br><textarea name="comments" rows="5" cols="80"></textarea><br><br>
<input type="submit" value="Send"></p>
</form>
</div>
<br>
<br>
<br>
<br>
<br>
<br><br>
<br>
<br><br>
<br>
<br>
<div><h2 style="font-size:30px;text-align:center;font-family:Comic">MEGA</h2></div>
<div><img style="height:800px;width:1000px;margin-left:150px;"src="mega1.jpg" ></div>
<div style="margin-left: 80px;border:5px;border-color:black;margin-top:30px;"><p style="text-align: center;">Shopping and entertainment center ,MEGA builts in the capital of Kazakhstan - Astana. SEC MEGA Astana is located in the most of built a new part of the city, on one of the main arteries of the capital. The proximity of large socially important objects of the capital, such as a circus, Wedding Palace, Oceanarium, a wellness center and prestigious residential complexes, contributes to the rapid development of the shopping center. The building, as well as in MEGA Almaty and Shymkent, is equipped with modern systems engineering equipment, fire safety, security and air-conditioning, which provides favorable conditions for buyers and tenants work.

</p></div>
<div style="border-style:solid;border-width:1px;float:left;background-color:#d4d4cb;width:600px;padding-left:20px;padding-top:25px;padding-bottom:10px;margin-left:300px">
<form action="mailto:myemail@domain.com" method="post">
<p>Comments and suggestions:<br><textarea name="comments" rows="5" cols="80"></textarea><br><br>
<input type="submit" value="Send"></p>
</form>
</div>
<br>
<br>
<br>
<br>
<br>
<br><br>
<br>
<br><br>
<br>
<br>

<div>
</body>
</html>