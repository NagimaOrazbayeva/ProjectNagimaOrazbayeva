<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link href="css/bootstrap.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/jquery.min.js"></script>
	<title>Registration</title>
	<style>
body{
background-image: url(astan.jpg);
background-size: 1400px;

}
</style>
</head>
<body>
<nav style="background-color: black;width:1365px;" class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="project.php"><span style="color: #8b7d6b;" class="glyphicon glyphicon-home" aria-hidden="true"></span></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="galery.php"><span style="color: #8b7d6b;" class="glyphicon glyphicon-camera" aria-hidden="true"></span> Galery<span class="sr-only">(current)</span></a></li>
        <li><a href="presentation.php"><span style="color: #8b7d6b;" class="glyphicon glyphicon-facetime-video" aria-hidden="true"></span> Presentation</a></li>
        <li><a href="information.php"><span style="color: #8b7d6b;" class="glyphicon glyphicon-file" aria-hidden="true"></span> Information about Astana</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span style="color: #8b7d6b;" class="glyphicon glyphicon-align-left" aria-hidden="true"></span> Categories<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="foods.php">Food</a></li>
            <li><a href="attractions.php">Attractions</a></li>
            
          </ul>
        </li>
      </ul>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" style="color: #8b7d6b;background-color: #ffe4c4;font-size: 16px;" class="form-control" placeholder="Search">
        </div>
        <button type="submit" style="color: white;background-color: #8b7d6b;" class="btn btn-default">Find</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.php"><span style="color: #8b7d6b;" class="glyphicon glyphicon-user" aria-hidden="true"></span> Log in</a></li>
        <li class="dropdown">
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<div style="margin-left: 500px;"><h1 style="font-family:Georgia;color:white;">PLEASE FILL ALL PLACE :)</h1></div>
<div style="margin-left: 500px;width:500px;height:500px;margin-top:50px;background-color: black;">
<div style="margin-left: 50px;width:400px;margin-top:50px;height:500px;background-color: black;">
	<form action="regprocess.php" method="POST" enctype="multipart/form-data" style="font-size:20px;color:white;">
		Name:
		<input style="width:200px;height:25px;font-size:20px;margin-left:45px;color:black;" type="text" name="name">
	<br>
	<br>
		Surname:
		<input style="width:200px;height:25px;font-size:20px;margin-left:45px;color:black;" type="text" name="surname">
	<br>
	<br>
		Login:
		<input style="width:200px;height:25px;font-size:20px;margin-left:45px;color:black;" type="text" name="login">
	<br>
	<br>
		Password:
		<input  style="width:200px;height:25px;font-size:20px;color:black;" type="password" name = "password"/>
		
	<br>
	<br>
  Your City:
    <input  style="width:200px;height:25px;font-size:20px;color:black;" type="text" name = "city"/>
    
  <br>
  <br>
		Gender:
		<input type="radio" name="gender" value="female">Female
		<input type="radio" name="gender" value="male">Male
<br>
<br>
  <br>
		<input  style="width:150px;height:35px;margin-left:10px;background-color: gray;color:black; font-size:20px;" type="submit" value="submit" name="registration">
	</form>
  </div>
  </div>
</body>
</html>