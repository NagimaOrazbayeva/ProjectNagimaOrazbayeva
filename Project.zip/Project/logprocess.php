<?php 
session_start();
include 'connection.php';
if (isset($_POST['log-in'])) {
	$login = $_POST['login'];
	$password = $_POST['password'];
	$sql = "SELECT * from registration where login=\"$login\" AND password=\"$password\" ";
	$res = mysqli_query($conn, $sql);
	if (mysqli_num_rows($res)>0) {
		$_SESSION['login'] = $login;
		header('location:project.php');	

	}
	else{
				header('location:login.php');
	}
}else{
	echo "you didn't logined";
}
?>