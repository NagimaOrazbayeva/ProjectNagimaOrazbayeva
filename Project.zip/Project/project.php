<?php 
session_start();
?>
<!DOCTYPE html>

<html>
<head><meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/jquery.min.js"></script>
	<title>Project</title>
	<style type="text/css">
  body{
    background-color: #ADD8E6;
  }
</style>
</head>
<body><!--<div style="float:left;"><embed src="music1.mp3" height="30" width="30" autostart="false"></embed></div> -->
<nav style="background-color: black;width:1365px;" class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="project.php"><span style="color: #000080;" class="glyphicon glyphicon-home" aria-hidden="true"></span></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="galery.php"><span style="color: #000080;" class="glyphicon glyphicon-camera" aria-hidden="true"></span> Galery<span class="sr-only">(current)</span></a></li>
        <li><a href="presentation.php"><span style="color: #000080;" class="glyphicon glyphicon-facetime-video" aria-hidden="true"></span> Presentation</a></li>
        <li><a href="information.php"><span style="color: #000080;" class="glyphicon glyphicon-file" aria-hidden="true"></span> Information about Astana</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span style="color: #000080;" class="glyphicon glyphicon-align-left" aria-hidden="true"></span> Categories<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="foods.php">Food</a></li>
            <li><a href="attractions.php">Attractions</a></li>
          
          </ul>
        </li>
      </ul>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" style="color: #000080;background-color: #B0E0E6;font-size: 16px;" class="form-control" placeholder="Search">
        </div>
        <button type="submit" style="color: white;background-color: blue;" class="btn btn-default">Find</button>
      </form>

      <ul class="nav navbar-nav navbar-right">
        <li><a href="logout.php"><span style="color: #000080;" class="glyphicon glyphicon-user" aria-hidden="true"></span> Log out</a></li>
        <li class="dropdown">
        </li></ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.php"><span style="color: #000080;" class="glyphicon glyphicon-user" aria-hidden="true"></span> Log in</a></li>
        <li class="dropdown">
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>



<div style="width:500px;height:100%;margin-top: -10px;margin-left:5%;"><img  style="width:1200px;height:200px;" src="lets.gif"></div>

<h1 align="center" style="color: black; font-family: Georgia">ASTANA</h1>
<!--COROUSEL!!!-->
<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <img src="astana_kazakhstan_panorama_20131021_1653712138.jpg" alt="...">
      <p style="position: absolute; left: 0%; top:50%;color:white;font-size:30px;text-align: center;background-color: black;opacity:0.7;">Astana - a modern city, which attracts tourists and comfortable for living residents and guests of the capital of Kazakhstan, with a favorable environment.Astana became the capital of the new Kazakhstan in 1998 for a number of reasons. By the end of XX century, the former capital of the country - Almaty - faced with a pile of problems hindering the further development of the city: the problem of overcrowding (more than 1.5 million inhabitants.); transport congestion highways; deteriorating environmental conditions. In addition, dense buildings "southern capital", in practice, leaving no room for the development of the modern city.</p>
      <div class="carousel-caption">
        ...
      </div>
    </div>
    <div class="item">
      <img src="Astana2.jpg" alt="...">
      <p style="position: absolute; left: 0%; top:50%;color:white;font-size:30px;text-align: center;background-color: black;opacity:0.7;"><b>Baiterek </b>- a monument in the capital of Kazakhstan, Astana, one of the main attractions of the city.The monument was built on the initiative of President Nursultan Nazarbayev, a hyphen capital from Almaty to Astana in 1997.The significance of "Baiterek", as a symbol of a new stage in the life of the Kazakh people, highlights the artistic composition "Ayaly Alakan", with a print of the right hand of President, located at an altitude of 97 meters, which symbolizes the 1997 - year of the proclamation of Astana a new capital of the state and, accordingly, a new point point in the history of the country.</p>
      <div class="carousel-caption">
        ...
      </div>
    </div>
    <div class="item">
      <img src="nastol.com.ua-44013.jpg" alt="...">
      <p style="position: absolute; left: 0%; top:50%;color:#000080;font-size:30px;color:white;text-align: center;background-color: black;opacity:0.7;"><strong>Hazrat Sultan </strong>- Mosque in Astana, the second largest mosque in Central Asia after the mosque in Turkmenistan "Spirituality of Turkmenbashi."<br>At the suggestion of Nursultan Nazarbayev Elbasy mosque named "Hazrat Sultan", which means "Holy Sultan". As is well known, "Hazrat Sultan" - one of the epithets Sufi sheikh Khoja Ahmed Yasavi, author of "Divan-i Hikmet", whose mausoleum is located in Turkistan.</p>
      <div class="carousel-caption">
        ...
      </div>
    ...
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
<divv class="devider"></div>
<div style="width:300px;height: 100px;position: absolute;left: 3%;float: left;">
<h3 style="font-size:13px;"> <span style="color: #000080;size:10px;"  class="glyphicon glyphicon-envelope" aria-hidden="true"></span>@adress:nagimaorazbayevaktl@gmail.com</h3>
<h3 style="font-size:13px;"> <span style="color: #000080; size:10px;"  class="glyphicon glyphicon-phone" aria-hidden="true"></span>@phone:87052071498</h3>
<h3 style="font-size:13px;"> <span style="color: #000080;size:10px;"  class="glyphicon glyphicon-oil" aria-hidden="true"></span>@building:Suleyman Demirel University</h3>
</div>
<div style="width:100px;height: 100px;margin-left:40%;float: left;margin-top: 20px;"><img  style="height:150px;width:200px;"src="vizitka.jpg"></div>
<div style="width:100px;height: 100px;margin-left:10%;float: left;margin-top: 20px;"><img style="height:150px;width:200px;" src="vizitka2.jpg"></div>
<div style="width:100px;height: 100px;margin-left:10%;float: left;margin-top: 20px;"><img style="height:150px;width:200px;" src="vizitka.png"></div>
</body>
</html>