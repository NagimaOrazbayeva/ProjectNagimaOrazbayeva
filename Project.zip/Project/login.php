<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="css/bootstrap.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>
    <script type="text/javascript" src="js/jquery.min.js"></script>

	<title>Login</title>
	<style type="text/css">
  body{
    background-color:#7fffd4;
  }
</style>
</head>
<body>
<nav style="background-color: black;width:1365px;" class="navbar navbar-default">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="project.php"><span style="color:#275c4b;" class="glyphicon glyphicon-home" aria-hidden="true"></span></a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="galery.php"><span style="color: #275c4b;" class="glyphicon glyphicon-camera" aria-hidden="true"></span> Galery<span class="sr-only">(current)</span></a></li>
        <li><a href="presentation.php"><span style="color:#275c4b;" class="glyphicon glyphicon-facetime-video" aria-hidden="true"></span> Presentation</a></li>
        <li><a href="information.php"><span style="color:#275c4b;" class="glyphicon glyphicon-file" aria-hidden="true"></span> Information about Astana</a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span style="color:#275c4b;" class="glyphicon glyphicon-align-left" aria-hidden="true"></span> Categories<span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="shopping.php">Shopping</a></li>
            <li><a href="foods.php">Food</a></li>
            <li><a href="attractions.php">Attractions</a></li>
            
          </ul>
        </li>
      </ul>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" style="color: #275c4b;background-color: #7fffd4;font-size: 16px;" class="form-control" placeholder="Search">
        </div>  
        <button type="submit" style="color: white;background-color: #275c4b;" class="btn btn-default">Find</button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.php"><span style="color: #275c4b;" class="glyphicon glyphicon-user" aria-hidden="true"></span> Log in</a></li>
        <li class="dropdown">
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<div style="margin-top:300px;margin-left:25%;">
<form class="form-inline" action="logprocess.php" method="post">
  <div class="form-group" style="background-color: #275c4b;">
    <label class="sr-only" >Login</label>
    <input type="text" style="background-color: #c0f2e1;width:300px;" name="login"class="form-control"  placeholder="nagima.orazbayeva@ce.sdu.edu.kz">
  </div>
  <div class="form-group" style="background-color: #275c4b">
    <label class="sr-only" >Password</label>
    <input type="password" class="form-control" name="password"style="background-color: #c0f2e1"  placeholder="Pasword">
  </div>
  <input type="submit" class="btn btn-default" name="log-in" value="submit" style="background-color:#275c4b">Sign in</b>
  <br>
  <br>
  <div style="margin-left:300px;" ><a href="registr.php" ><p>Registration</p></a></div>
</form>
</div>
</body>
</html>